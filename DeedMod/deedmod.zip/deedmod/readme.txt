==Instructions==

Install Ago's mod loader. You can find it here: http://forum.wurmonline.com/index.php?/topic/133085-alpha-single-player-priest-mod-mod-loader/

Unzip this archive into the mod/ folder.

You should see a set up like this when done:

(Replace dedicated server with Wurm Unlimited\WurmServerLauncher\ for bundled servers)
Wurm Unlimited Dedicated Server\mods\deedmod.properties
Wurm Unlimited Dedicated Server\mods\deedmod\
Wurm Unlimited Dedicated Server\mods\deedmod\DeedMod.jar

Start your server with the batch file provided with Ago's loader: modlauncher.bat

Profit!

See deedmod.properties for settings.